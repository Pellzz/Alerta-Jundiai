
const express = require("express");

const {
    listarAlagamentos,
    buscarAlagamento,
    criarAlagamento,
    atualizarAlagamento,
    deletarAlagamento
} = require("../controllers/alagamentoController");

const verificarAdmin = require("../middlewares/verificarAdmin");

const router = express.Router();

router.get("/alagamentos", listarAlagamentos);

router.get("/alagamentos/:id", buscarAlagamento);

router.post("/alagamentos", criarAlagamento);

router.put("/alagamentos/:id", atualizarAlagamento);

// Somente administrador pode excluir
router.delete("/alagamentos/:id", verificarAdmin, deletarAlagamento);

module.exports = router;
