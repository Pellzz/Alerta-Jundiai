
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const alagamentoRoutes = require("./routes/alagamentoRoutes");

const app = express();

app.use(cors());
app.use(express.json());

// Rota inicial
app.get("/", (req, res) => {
    res.json({
        projeto: "Alerta Jundiaí",
        status: "API funcionando"
    });
});

// Login exclusivo do administrador
app.post("/admin/login", (req, res) => {
    const { usuario, senha } = req.body;

    if (!usuario || !senha) {
        return res.status(400).json({
            erro: "Informe usuário e senha."
        });
    }

    if (
        usuario !== process.env.ADMIN_USER ||
        senha !== process.env.ADMIN_PASSWORD
    ) {
        return res.status(401).json({
            erro: "Usuário ou senha incorretos."
        });
    }

    const token = jwt.sign(
        { tipo: "admin" },
        process.env.JWT_SECRET,
        { expiresIn: "2h" }
    );

    return res.json({
        mensagem: "Login realizado com sucesso!",
        token: token
    });
});

// Rotas dos alagamentos
app.use("/", alagamentoRoutes);

// Tratamento de rota inexistente
app.use((req, res) => {
    res.status(404).json({
        erro: "Rota não encontrada."
    });
});

module.exports = app;
