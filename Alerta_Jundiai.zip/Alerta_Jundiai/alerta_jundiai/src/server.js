require("dotenv").config();

const app = require("./app");
const pool = require("./database/connection");

const PORT = process.env.PORT || 3000;

app.listen(PORT, async () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);

    try {
        await pool.query("SELECT NOW()");
        console.log("Conexão com PostgreSQL realizada com sucesso!");
    } catch (erro) {
        console.error("Erro ao conectar com PostgreSQL:");
console.error(erro);
    }
});