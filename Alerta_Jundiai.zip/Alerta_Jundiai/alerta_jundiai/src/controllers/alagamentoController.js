const pool = require("../database/connection");

// GET /alagamentos
async function listarAlagamentos(req, res) {
    try {
        const resultado = await pool.query(
            "SELECT * FROM alagamentos ORDER BY data_criacao DESC"
        );

        res.status(200).json(resultado.rows);

    } catch (erro) {
        console.error(erro);

        res.status(500).json({
            erro: "Erro ao buscar os alagamentos."
        });
    }
}

// GET /alagamentos/:id
async function buscarAlagamento(req, res) {
    try {
        const { id } = req.params;

        const resultado = await pool.query(
            "SELECT * FROM alagamentos WHERE id = $1",
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                erro: "Alagamento não encontrado."
            });
        }

        res.status(200).json(resultado.rows[0]);

    } catch (erro) {
        console.error(erro);

        res.status(500).json({
            erro: "Erro ao buscar o alagamento."
        });
    }
}

// POST /alagamentos
async function criarAlagamento(req, res) {
    try {
        const {
            latitude,
            longitude,
            gravidade,
            descricao
        } = req.body;

        // Validação dos campos obrigatórios
        if (
            latitude === undefined ||
            longitude === undefined ||
            !gravidade
        ) {
            return res.status(400).json({
                erro: "Latitude, longitude e gravidade são obrigatórios."
            });
        }

        // Validação da gravidade
        const gravidadesPermitidas = [
            "baixa",
            "media",
            "alta"
        ];

        if (!gravidadesPermitidas.includes(gravidade.toLowerCase())) {
            return res.status(400).json({
                erro: "Gravidade deve ser baixa, media ou alta."
            });
        }

        // Validação das coordenadas
        if (
            latitude < -90 ||
            latitude > 90 ||
            longitude < -180 ||
            longitude > 180
        ) {
            return res.status(400).json({
                erro: "Latitude ou longitude inválida."
            });
        }

        const resultado = await pool.query(
            `
            INSERT INTO alagamentos
            (latitude, longitude, gravidade, descricao)
            VALUES ($1, $2, $3, $4)
            RETURNING *
            `,
            [
                latitude,
                longitude,
                gravidade.toLowerCase(),
                descricao || null
            ]
        );

        res.status(201).json({
            mensagem: "Alagamento cadastrado com sucesso.",
            alagamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error(erro);

        res.status(500).json({
            erro: "Erro ao cadastrar o alagamento."
        });
    }
}

// PUT /alagamentos/:id (Atualizar um alerta)
async function atualizarAlagamento(req, res) {
    try {
        const { id } = req.params;
        const { gravidade, descricao } = req.body;

        // Validação da gravidade se foi enviada
        if (!gravidade) {
            return res.status(400).json({
                erro: "Gravidade é obrigatória para atualizar."
            });
        }

        const gravidadesPermitidas = ["baixa", "media", "alta"];
        if (!gravidadesPermitidas.includes(gravidade.toLowerCase())) {
            return res.status(400).json({
                erro: "Gravidade deve ser baixa, media ou alta."
            });
        }

        const resultado = await pool.query(
            `
            UPDATE alagamentos 
            SET gravidade = $1, descricao = $2 
            WHERE id = $3 
            RETURNING *
            `,
            [gravidade.toLowerCase(), descricao || null, id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                erro: "Alagamento não encontrado."
            });
        }

        res.status(200).json({
            mensagem: "Alagamento atualizado com sucesso.",
            alagamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error(erro);
        res.status(500).json({
            erro: "Erro ao atualizar o alagamento."
        });
    }
}

// DELETE /alagamentos/:id (Deletar um alerta falso ou resolvido)
async function deletarAlagamento(req, res) {
    try {
        const { id } = req.params;

        const resultado = await pool.query(
            "DELETE FROM alagamentos WHERE id = $1 RETURNING *",
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                erro: "Alagamento não encontrado."
            });
        }

        res.status(200).json({
            mensagem: "Alagamento deletado com sucesso.",
            alagamento: resultado.rows[0]
        });

    } catch (erro) {
        console.error(erro);
        res.status(500).json({
            erro: "Erro ao deletar o alagamento."
        });
    }
}

module.exports = {
    listarAlagamentos,
    buscarAlagamento,
    criarAlagamento,
    atualizarAlagamento,
    deletarAlagamento
};