
const jwt = require("jsonwebtoken");

function verificarAdmin(req, res, next) {
    const autorizacao = req.headers.authorization;

    if (!autorizacao) {
        return res.status(401).json({
            erro: "Acesso não autorizado"
        });
    }

    const token = autorizacao.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            erro: "Token não informado"
        });
    }

    try {
        const dados = jwt.verify(token, process.env.JWT_SECRET);

        if (dados.tipo !== "admin") {
            return res.status(403).json({
                erro: "Acesso permitido somente ao administrador"
            });
        }

        next();

    } catch (erro) {
        return res.status(401).json({
            erro: "Token inválido ou expirado"
        });
    }
}

module.exports = verificarAdmin;
