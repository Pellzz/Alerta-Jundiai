package br.com.alertajundiai.alerta_jundiai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
