import 'dart:convert';
import 'package:http/http.dart' as http;

/// Endereço da API.
/// - Emulador Android:        http://10.0.2.2:3000
/// - Celular físico (mesmo Wi-Fi do PC): http://IP_DO_SEU_PC:3000
/// - Produção: https://sua-api.com
const String baseUrl = 'http://10.0.2.2:3000';

class Alagamento {
  final String id;
  final double latitude;
  final double longitude;
  final String gravidade; // baixa | media | alta
  final String? descricao;
  final DateTime? dataCriacao;

  Alagamento({
    required this.id,
    required this.latitude,
    required this.longitude,
    required this.gravidade,
    this.descricao,
    this.dataCriacao,
  });

  factory Alagamento.fromJson(Map<String, dynamic> j) => Alagamento(
        id: j['id'].toString(),
        // O PostgreSQL pode devolver NUMERIC como texto, por isso o toString()
        latitude: double.parse(j['latitude'].toString()),
        longitude: double.parse(j['longitude'].toString()),
        gravidade: j['gravidade'].toString().toLowerCase(),
        descricao: j['descricao']?.toString(),
        dataCriacao: j['data_criacao'] != null
            ? DateTime.tryParse(j['data_criacao'].toString())?.toLocal()
            : null,
      );
}

/// Lançada quando o token do admin expirou (a API devolve 401/403).
class SessaoExpiradaException implements Exception {}

class ApiService {
  static const _timeout = Duration(seconds: 10);

  static String _mensagemErro(http.Response r, String padrao) {
    try {
      return jsonDecode(utf8.decode(r.bodyBytes))['erro'] ?? padrao;
    } catch (_) {
      return padrao;
    }
  }

  /// GET /alagamentos
  static Future<List<Alagamento>> listar() async {
    final r = await http.get(Uri.parse('$baseUrl/alagamentos')).timeout(_timeout);
    if (r.statusCode != 200) {
      throw Exception('Erro ${r.statusCode} ao buscar ocorrências');
    }
    final List dados = jsonDecode(utf8.decode(r.bodyBytes));
    return dados
        .map((e) => Alagamento.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// POST /alagamentos
  static Future<void> criar({
    required double latitude,
    required double longitude,
    required String gravidade,
    required String descricao,
  }) async {
    final r = await http
        .post(
          Uri.parse('$baseUrl/alagamentos'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'latitude': latitude,
            'longitude': longitude,
            'gravidade': gravidade,
            'descricao': descricao,
          }),
        )
        .timeout(_timeout);

    if (r.statusCode != 201) {
      throw Exception(_mensagemErro(r, 'Erro ${r.statusCode} ao registrar'));
    }
  }

  /// POST /admin/login  -> devolve o token JWT (válido por 2h)
  static Future<String> loginAdmin(String usuario, String senha) async {
    final r = await http
        .post(
          Uri.parse('$baseUrl/admin/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'usuario': usuario, 'senha': senha}),
        )
        .timeout(_timeout);

    if (r.statusCode != 200) {
      throw Exception(_mensagemErro(r, 'Falha no login (${r.statusCode})'));
    }
    return jsonDecode(utf8.decode(r.bodyBytes))['token'] as String;
  }

  /// DELETE /alagamentos/:id  (exige token de admin)
  static Future<void> deletar(String id, String token) async {
    final r = await http.delete(
      Uri.parse('$baseUrl/alagamentos/$id'),
      headers: {'Authorization': 'Bearer $token'},
    ).timeout(_timeout);

    if (r.statusCode == 401 || r.statusCode == 403) {
      throw SessaoExpiradaException();
    }
    if (r.statusCode != 200) {
      throw Exception(_mensagemErro(r, 'Erro ${r.statusCode} ao excluir'));
    }
  }
}
