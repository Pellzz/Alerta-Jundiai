import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'api.dart';

void main() => runApp(const AlertaJundiaiApp());

// ------------------------------------------------------------------- Mapa

/// true  = tiles do Google Maps (endereço NÃO oficial, contra os termos do Google;
///         use só em trabalho escolar/estudo, sem publicar o app)
/// false = mapa padrão do OpenStreetMap (gratuito e permitido)
const bool usarMapaGoogle = true;

const _urlGoogle = 'https://mt1.google.com/vt/lyrs=m&hl=pt-BR&x={x}&y={y}&z={z}';
const _urlOsm = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

// ------------------------------------------------------------------ Estilo

const _azul = Color(0xFF1A73E8);
const _azulClaro = Color(0xFFE8F0FE);
const _sombra = Color(0x40000000);

Color corDaGravidade(String g) => switch (g) {
      'alta' => const Color(0xFFD93025),
      'media' => const Color(0xFFE8710A),
      _ => const Color(0xFFF9AB00),
    };

String rotuloGravidade(String g) => switch (g) {
      'alta' => 'Alta',
      'media' => 'Média',
      _ => 'Baixa',
    };

String formatarData(DateTime d) {
  String dois(int n) => n.toString().padLeft(2, '0');
  return '${dois(d.day)}/${dois(d.month)}/${d.year} às ${dois(d.hour)}:${dois(d.minute)}';
}

class AlertaJundiaiApp extends StatelessWidget {
  const AlertaJundiaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alerta Jundiaí',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: _azul),
      ),
      home: const MapaPage(),
    );
  }
}

/// Pino estilo Google Maps. A ponta fica na parte de baixo do widget.
class PinMapa extends StatelessWidget {
  final Color cor;
  final double tamanho;
  const PinMapa({super.key, required this.cor, this.tamanho = 46});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: tamanho,
      height: tamanho,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          // círculo branco que aparece no "furo" do pino
          Positioned(
            top: tamanho * 0.2,
            child: Container(
              width: tamanho * 0.3,
              height: tamanho * 0.3,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Icon(
            Icons.location_on,
            size: tamanho,
            color: cor,
            shadows: const [
              Shadow(color: _sombra, blurRadius: 6, offset: Offset(0, 2)),
            ],
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ Tela

class MapaPage extends StatefulWidget {
  const MapaPage({super.key});

  @override
  State<MapaPage> createState() => _MapaPageState();
}

class _MapaPageState extends State<MapaPage> {
  static const _centroJundiai = LatLng(-23.1857, -46.8978);

  final _mapController = MapController();
  List<Alagamento> _alagamentos = [];
  LatLng? _pontoSelecionado;
  String? _filtro; // null = todas
  bool _carregando = true;
  bool _buscandoGps = false;

  /// Token do administrador (null = usuário comum). Fica só em memória.
  String? _tokenAdmin;
  bool get _ehAdmin => _tokenAdmin != null;

  List<Alagamento> get _visiveis => _filtro == null
      ? _alagamentos
      : _alagamentos.where((a) => a.gravidade == _filtro).toList();

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  @override
  void dispose() {
    _mapController.dispose();
    super.dispose();
  }

  void _msg(String texto) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(texto),
        behavior: SnackBarBehavior.floating,
      ));
  }

  Future<void> _carregar() async {
    setState(() => _carregando = true);
    try {
      final lista = await ApiService.listar();
      if (!mounted) return;
      setState(() => _alagamentos = lista);
    } catch (_) {
      _msg('Não foi possível carregar as ocorrências.');
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  // ---------------------------------------------------------------- GPS

  Future<void> _usarMinhaLocalizacao() async {
    setState(() => _buscandoGps = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _msg('Ative o GPS do celular e tente de novo.');
        return;
      }

      var permissao = await Geolocator.checkPermission();
      if (permissao == LocationPermission.denied) {
        permissao = await Geolocator.requestPermission();
      }
      if (permissao == LocationPermission.denied) {
        _msg('Permissão de localização negada.');
        return;
      }
      if (permissao == LocationPermission.deniedForever) {
        _msg('Permissão negada. Libere a localização nas configurações do app.');
        await Geolocator.openAppSettings();
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );

      final ponto = LatLng(pos.latitude, pos.longitude);
      _mapController.move(ponto, 17);
      if (mounted) setState(() => _pontoSelecionado = ponto);
    } catch (_) {
      _msg('Não foi possível obter sua localização.');
    } finally {
      if (mounted) setState(() => _buscandoGps = false);
    }
  }

  // -------------------------------------------------------------- Admin

  Future<void> _loginOuLogout() async {
    if (_ehAdmin) {
      setState(() => _tokenAdmin = null);
      _msg('Você saiu do modo administrador.');
      return;
    }
    final token = await showDialog<String>(
      context: context,
      builder: (_) => const LoginAdminDialog(),
    );
    if (token != null && mounted) {
      setState(() => _tokenAdmin = token);
      _msg('Modo administrador ativado.');
    }
  }

  /// Chamado DEPOIS que a folha de detalhes já foi fechada.
  Future<void> _excluir(Alagamento a) async {
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excluir ocorrência?'),
        content: const Text('Essa ação não pode ser desfeita.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmou != true || !mounted) return;

    try {
      await ApiService.deletar(a.id, _tokenAdmin!);
      if (!mounted) return;
      // Remove na hora da lista local e depois sincroniza com a API
      setState(() => _alagamentos.removeWhere((x) => x.id == a.id));
      _msg('Ocorrência excluída.');
      _carregar();
    } on SessaoExpiradaException {
      if (mounted) setState(() => _tokenAdmin = null);
      _msg('Sessão de administrador expirada. Entre novamente.');
    } catch (e) {
      _msg(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  // ----------------------------------------------------------- Detalhes

  Future<void> _mostrarDetalhes(Alagamento a) async {
    final acao = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (sheetContext) => DetalhesOcorrencia(
        alagamento: a,
        ehAdmin: _ehAdmin,
        // Só devolve um resultado; quem fecha a folha é o showModalBottomSheet
        onExcluir: () => Navigator.pop(sheetContext, 'excluir'),
      ),
    );
    if (acao == 'excluir') {
      await _excluir(a);
    }
  }

  // --------------------------------------------------------- Formulário

  Future<void> _abrirFormulario() async {
    final ponto = _pontoSelecionado;
    if (ponto == null) return;

    final salvou = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (_) => FormOcorrencia(ponto: ponto),
    );

    if (salvou == true && mounted) {
      setState(() => _pontoSelecionado = null);
      _msg('Ocorrência registrada com sucesso!');
      _carregar();
    }
  }

  // -------------------------------------------------------------- Widgets

  Widget _barraSuperior() {
    final total = _visiveis.length;
    final subtitulo = _carregando
        ? 'Atualizando...'
        : total == 0
            ? 'Nenhuma ocorrência'
            : total == 1
                ? '1 ocorrência no mapa'
                : '$total ocorrências no mapa';

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Material(
              color: Colors.white,
              elevation: 4,
              shadowColor: _sombra,
              borderRadius: BorderRadius.circular(30),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 4, 6),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 20,
                      backgroundColor: _azulClaro,
                      child: Icon(Icons.water_drop, color: _azul, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Alerta Jundiaí',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                          Text(
                            subtitulo,
                            style: const TextStyle(
                                fontSize: 12, color: Colors.black54),
                          ),
                        ],
                      ),
                    ),
                    if (_ehAdmin)
                      Container(
                        margin: const EdgeInsets.only(right: 4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _azulClaro,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          'ADMIN',
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: _azul),
                        ),
                      ),
                    IconButton(
                      tooltip: 'Atualizar',
                      icon: const Icon(Icons.refresh),
                      onPressed: _carregando ? null : _carregar,
                    ),
                    IconButton(
                      tooltip: _ehAdmin
                          ? 'Sair do modo administrador'
                          : 'Entrar como administrador',
                      icon: Icon(
                        _ehAdmin
                            ? Icons.admin_panel_settings
                            : Icons.lock_outline,
                        color: _ehAdmin ? _azul : null,
                      ),
                      onPressed: _loginOuLogout,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  _chipFiltro(null, 'Todas'),
                  _chipFiltro('alta', 'Alta'),
                  _chipFiltro('media', 'Média'),
                  _chipFiltro('baixa', 'Baixa'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chipFiltro(String? valor, String rotulo) {
    final ativo = _filtro == valor;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(rotulo),
        avatar: valor == null
            ? null
            : Icon(Icons.circle, size: 12, color: corDaGravidade(valor)),
        selected: ativo,
        showCheckmark: false,
        backgroundColor: Colors.white,
        selectedColor: _azulClaro,
        elevation: 3,
        pressElevation: 1,
        shadowColor: _sombra,
        side: BorderSide(color: ativo ? _azul : Colors.transparent),
        labelStyle: TextStyle(
          color: ativo ? _azul : Colors.black87,
          fontWeight: FontWeight.w500,
        ),
        onSelected: (_) => setState(() => _filtro = valor),
      ),
    );
  }

  Widget _dica() {
    final vazio = !_carregando && _alagamentos.isEmpty;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Material(
          color: Colors.white,
          elevation: 4,
          shadowColor: _sombra,
          borderRadius: BorderRadius.circular(24),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(vazio ? Icons.check_circle_outline : Icons.touch_app_outlined,
                    size: 18, color: vazio ? Colors.green : _azul),
                const SizedBox(width: 8),
                Text(
                  vazio
                      ? 'Nenhuma ocorrência registrada'
                      : 'Toque no mapa para registrar',
                  style: const TextStyle(fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _cartaoLocal(LatLng ponto) {
    return Material(
      color: Colors.white,
      elevation: 8,
      shadowColor: _sombra,
      borderRadius: BorderRadius.circular(24),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.place, color: _azul),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Local selecionado',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600)),
                      Text(
                        '${ponto.latitude.toStringAsFixed(5)}, ${ponto.longitude.toStringAsFixed(5)}',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Cancelar',
                  icon: const Icon(Icons.close),
                  onPressed: () => setState(() => _pontoSelecionado = null),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _abrirFormulario,
                  icon: const Icon(Icons.add_alert),
                  label: const Text('Registrar ocorrência'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // -------------------------------------------------------------- Build

  @override
  Widget build(BuildContext context) {
    final base = MediaQuery.of(context).padding.bottom + 44;
    final selecionado = _pontoSelecionado;

    final marcadores = <Marker>[
      for (final a in _visiveis)
        Marker(
          point: LatLng(a.latitude, a.longitude),
          width: 46,
          height: 46,
          alignment: Alignment.topCenter, // a ponta do pino fica no ponto
          child: GestureDetector(
            onTap: () => _mostrarDetalhes(a),
            child: PinMapa(cor: corDaGravidade(a.gravidade)),
          ),
        ),
      if (selecionado != null)
        Marker(
          point: selecionado,
          width: 52,
          height: 52,
          alignment: Alignment.topCenter,
          child: const PinMapa(cor: _azul, tamanho: 52),
        ),
    ];

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: _centroJundiai,
                initialZoom: 13,
                minZoom: 3,
                maxZoom: 19,
                onTap: (_, ponto) => setState(() => _pontoSelecionado = ponto),
              ),
              children: [
                TileLayer(
                  urlTemplate: usarMapaGoogle ? _urlGoogle : _urlOsm,
                  // Se o Google bloquear os tiles, cai para o OpenStreetMap
                  fallbackUrl: usarMapaGoogle ? _urlOsm : null,
                  userAgentPackageName: 'br.com.alertajundiai.alerta_jundiai',
                  maxNativeZoom: 19,
                  // Mostra no terminal do "flutter run" o motivo de um tile falhar
                  errorTileCallback: (tile, error, stackTrace) =>
                      debugPrint('Erro ao carregar tile do mapa: $error'),
                ),
                MarkerLayer(markers: marcadores),
                RichAttributionWidget(
                  alignment: AttributionAlignment.bottomLeft,
                  attributions: [
                    TextSourceAttribution(
                      usarMapaGoogle ? '© Google Maps' : 'OpenStreetMap contributors',
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(top: 0, left: 0, right: 0, child: _barraSuperior()),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 200),
            right: 12,
            bottom: selecionado == null ? base : base + 150,
            child: FloatingActionButton(
              heroTag: 'gps',
              tooltip: 'Usar minha localização',
              backgroundColor: Colors.white,
              foregroundColor: _azul,
              elevation: 4,
              onPressed: _buscandoGps ? null : _usarMinhaLocalizacao,
              child: _buscandoGps
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5),
                    )
                  : const Icon(Icons.my_location),
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: base,
            child: selecionado == null ? _dica() : _cartaoLocal(selecionado),
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------- Detalhes da ocorrência

class DetalhesOcorrencia extends StatelessWidget {
  final Alagamento alagamento;
  final bool ehAdmin;
  final VoidCallback onExcluir;

  const DetalhesOcorrencia({
    super.key,
    required this.alagamento,
    required this.ehAdmin,
    required this.onExcluir,
  });

  Widget _linha(IconData icone, String texto) {
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icone, size: 20, color: Colors.black54),
          const SizedBox(width: 12),
          Expanded(child: Text(texto, style: const TextStyle(fontSize: 14.5))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final a = alagamento;
    final cor = corDaGravidade(a.gravidade);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: cor.withAlpha(40),
                  child: Icon(Icons.water_drop, color: cor),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Alagamento',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: cor.withAlpha(40),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'Gravidade ${rotuloGravidade(a.gravidade).toLowerCase()}',
                          style: TextStyle(
                              color: cor,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Divider(height: 28),
            _linha(
              Icons.notes,
              a.descricao?.isNotEmpty == true ? a.descricao! : 'Sem descrição',
            ),
            if (a.dataCriacao != null)
              _linha(Icons.schedule, 'Registrado em ${formatarData(a.dataCriacao!)}'),
            _linha(
              Icons.place_outlined,
              '${a.latitude.toStringAsFixed(5)}, ${a.longitude.toStringAsFixed(5)}',
            ),
            if (ehAdmin) ...[
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onExcluir,
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Excluir ocorrência'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFD93025),
                    side: const BorderSide(color: Color(0xFFD93025)),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------- Login do admin

class LoginAdminDialog extends StatefulWidget {
  const LoginAdminDialog({super.key});

  @override
  State<LoginAdminDialog> createState() => _LoginAdminDialogState();
}

class _LoginAdminDialogState extends State<LoginAdminDialog> {
  final _usuarioCtrl = TextEditingController();
  final _senhaCtrl = TextEditingController();
  bool _enviando = false;
  bool _ocultarSenha = true;
  String? _erro;

  @override
  void dispose() {
    _usuarioCtrl.dispose();
    _senhaCtrl.dispose();
    super.dispose();
  }

  Future<void> _entrar() async {
    if (_usuarioCtrl.text.trim().isEmpty || _senhaCtrl.text.isEmpty) {
      setState(() => _erro = 'Informe usuário e senha.');
      return;
    }
    setState(() {
      _enviando = true;
      _erro = null;
    });
    try {
      final token =
          await ApiService.loginAdmin(_usuarioCtrl.text.trim(), _senhaCtrl.text);
      if (mounted && Navigator.canPop(context)) Navigator.pop(context, token);
    } catch (e) {
      if (mounted) {
        setState(() {
          _erro = e.toString().replaceFirst('Exception: ', '');
          _enviando = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      title: const Text('Acesso do administrador'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _usuarioCtrl,
            decoration: const InputDecoration(
              labelText: 'Usuário',
              prefixIcon: Icon(Icons.person_outline),
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _senhaCtrl,
            obscureText: _ocultarSenha,
            decoration: InputDecoration(
              labelText: 'Senha',
              prefixIcon: const Icon(Icons.lock_outline),
              suffixIcon: IconButton(
                icon: Icon(
                    _ocultarSenha ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _ocultarSenha = !_ocultarSenha),
              ),
            ),
            onSubmitted: (_) => _entrar(),
          ),
          if (_erro != null) ...[
            const SizedBox(height: 12),
            Text(_erro!,
                style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _enviando ? null : () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: _enviando ? null : _entrar,
          child: _enviando
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Entrar'),
        ),
      ],
    );
  }
}

// ------------------------------------------------- Formulário de registro

class FormOcorrencia extends StatefulWidget {
  final LatLng ponto;
  const FormOcorrencia({super.key, required this.ponto});

  @override
  State<FormOcorrencia> createState() => _FormOcorrenciaState();
}

class _FormOcorrenciaState extends State<FormOcorrencia> {
  final _formKey = GlobalKey<FormState>();
  final _descricaoCtrl = TextEditingController();
  String? _gravidade;
  bool _semGravidade = false;
  bool _enviando = false;
  String? _erro;

  @override
  void dispose() {
    _descricaoCtrl.dispose();
    super.dispose();
  }

  Future<void> _enviar() async {
    final formOk = _formKey.currentState!.validate();
    if (_gravidade == null) setState(() => _semGravidade = true);
    if (!formOk || _gravidade == null) return;

    setState(() {
      _enviando = true;
      _erro = null;
    });
    try {
      await ApiService.criar(
        latitude: widget.ponto.latitude,
        longitude: widget.ponto.longitude,
        gravidade: _gravidade!,
        descricao: _descricaoCtrl.text.trim(),
      );
      if (mounted && Navigator.canPop(context)) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() {
          _erro = e.toString().replaceFirst('Exception: ', '');
          _enviando = false;
        });
      }
    }
  }

  ButtonSegment<String> _segmento(String valor, String rotulo) {
    return ButtonSegment<String>(
      value: valor,
      label: Text(rotulo),
      icon: Icon(Icons.circle, size: 12, color: corDaGravidade(valor)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Nova ocorrência',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(
                '${widget.ponto.latitude.toStringAsFixed(5)}, ${widget.ponto.longitude.toStringAsFixed(5)}',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 20),
              const Text('Gravidade',
                  style: TextStyle(fontWeight: FontWeight.w500)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                emptySelectionAllowed: true,
                showSelectedIcon: false,
                segments: [
                  _segmento('baixa', 'Baixa'),
                  _segmento('media', 'Média'),
                  _segmento('alta', 'Alta'),
                ],
                selected: _gravidade == null ? <String>{} : {_gravidade!},
                onSelectionChanged: (s) => setState(() {
                  _gravidade = s.isEmpty ? null : s.first;
                  _semGravidade = false;
                }),
              ),
              if (_semGravidade)
                Padding(
                  padding: const EdgeInsets.only(top: 6, left: 4),
                  child: Text(
                    'Selecione a gravidade',
                    style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                        fontSize: 12),
                  ),
                ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descricaoCtrl,
                maxLines: 3,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                  labelText: 'Descrição',
                  hintText: 'Ex: Água invadindo o passeio...',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Descreva a ocorrência'
                    : null,
              ),
              if (_erro != null) ...[
                const SizedBox(height: 12),
                Text(_erro!,
                    style:
                        TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _enviando ? null : _enviar,
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: _enviando
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Registrar ocorrência'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
